var modelo_densa = null;
var modelo_perceptron = null;

(async () => {
    try {
        console.log("Cargando modelos...");
        
        // Intentamos cargar el modelo normalmente
        modelo_perceptron = await tf.loadLayersModel("./modelo_perceptron_web/model.json");
        console.log("Modelo perceptrón cargado.");

        modelo_densa = await tf.loadLayersModel("./modelo_densa_web/model.json");
        console.log("Modelo densa cargado.");

    } catch (error) {
        console.error("Error al cargar:", error);
        // Si el error persiste, aquí podríamos intentar cargarlo 
        // como un 'Graph Model' si la estructura de capas falla.
    }
})();

function predecir() {
    // Ocultamos la tabla hasta tener los resultados
    document.getElementById("tabla-resultados").style.display = "none";

    if (modelo_densa != null && modelo_perceptron != null) {
        // 1. Obtener el valor del input HTML
        var celsius = document.getElementById("celsius").value;
        
        // 2. Convertir a Tensor (TensorFlow espera arreglos de 2 dimensiones)
        // Ejemplo: [ [25] ]
        var tensor = tf.tensor2d([[parseFloat(celsius)]]);

        // 3. Hacer la predicción
        var prediccion_densa = modelo_densa.predict(tensor);
        var prediccion_perceptron = modelo_perceptron.predict(tensor);

        // 4. Obtener el valor numérico y redondearlo
        // dataSync() extrae los datos del tensor a JavaScript
        var resultado_densa = prediccion_densa.dataSync()[0];
        resultado_densa = Math.round(resultado_densa * 100) / 100;

        var resultado_perceptron = prediccion_perceptron.dataSync()[0];
        resultado_perceptron = Math.round(resultado_perceptron * 100) / 100;

        // 5. Calculamos el resultado real para comparar
        var resultado_real = (celsius * 1.8) + 32;

        // 6. Mostrar Resultados en la Tabla ---
        document.getElementById("res-real").innerText = resultado_real.toFixed(2);
        document.getElementById("res-densa").innerText = resultado_densa.toFixed(2);
        document.getElementById("res-perceptron").innerText = resultado_perceptron.toFixed(2);

        // 7. Hacer visible la tabla
        document.getElementById("tabla-resultados").style.display = "table";
    } else {
        document.getElementById("resultado").innerHTML = "El modelo aún no carga...";
    }
}