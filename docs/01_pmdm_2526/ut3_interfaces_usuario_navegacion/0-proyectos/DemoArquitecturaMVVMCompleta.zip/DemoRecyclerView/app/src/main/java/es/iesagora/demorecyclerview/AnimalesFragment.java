package es.iesagora.demorecyclerview;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.demorecyclerview.adapter.AnimalesAdapter;
import es.iesagora.demorecyclerview.databinding.FragmentAnimalesBinding;
import es.iesagora.demorecyclerview.model.Animal;
import es.iesagora.demorecyclerview.repository.AnimalesRepository;
import es.iesagora.demorecyclerview.viewmodel.AnimalesViewModel;


public class AnimalesFragment extends Fragment {

    private FragmentAnimalesBinding binding;
    private AnimalesViewModel viewModel;
    AnimalesAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAnimalesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(AnimalesViewModel.class);

        // Configuramos el RecyclerView
        adapter = new AnimalesAdapter(requireContext(), new ArrayList<>(), viewModel);
        binding.recyclerView.setAdapter(adapter);
        binding.recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2));

        // Observamos los datos del LiveData
        viewModel.animales.observe(getViewLifecycleOwner(), lista -> {
            adapter.establecerLista(lista);
        });

        // Llamamos al método que recupera los animales
        viewModel.obtenerAnimales();

        // Evento de búsqueda sobre el searchView
        binding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            // Método que se ejecuta cuando el usuario le da a intro
            // No nos interesa implementarlo
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            // Método que se ejecuta cada vez que el usuario escribe una letra en el searchView
            @Override
            public boolean onQueryTextChange(String texto) {
                viewModel.buscarAnimalPorNombre(texto);
                return true;
            }
        });

        eventoEliminarElto(view);
    }

    private void eventoEliminarElto(View view) {
        ItemTouchHelper.SimpleCallback callback = new ItemTouchHelper.SimpleCallback(
                0, // No permitimos mover elementos (drag)
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT // Permitimos deslizar a izquierda o derecha
        ) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                // No necesitamos implementar el movimiento (solo eliminación)
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // 1. Obtenemos la posición del elemento deslizado
                int position = viewHolder.getBindingAdapterPosition();

                if (position != RecyclerView.NO_POSITION) {
                    viewModel.eliminarAnimal(position);
}
            }
        };

        // Asociamos el callback al RecyclerView
        new ItemTouchHelper(callback).attachToRecyclerView(binding.recyclerView);
    }
}