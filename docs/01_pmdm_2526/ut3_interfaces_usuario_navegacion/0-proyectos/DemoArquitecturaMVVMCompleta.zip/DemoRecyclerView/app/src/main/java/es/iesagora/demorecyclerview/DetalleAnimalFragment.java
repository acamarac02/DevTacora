package es.iesagora.demorecyclerview;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import es.iesagora.demorecyclerview.databinding.FragmentDetalleAnimalBinding;
import es.iesagora.demorecyclerview.model.Animal;
import es.iesagora.demorecyclerview.viewmodel.AnimalesViewModel;

public class DetalleAnimalFragment extends Fragment {
    private FragmentDetalleAnimalBinding binding;
    private AnimalesViewModel viewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDetalleAnimalBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Obtenemos el ViewModel compartido (misma instancia que en AnimalesFragment)
        viewModel = new ViewModelProvider(requireActivity()).get(AnimalesViewModel.class);

        // Observamos el animal seleccionado
        viewModel.animalSeleccionado.observe(getViewLifecycleOwner(), animal -> {
            if (animal != null) {
                // Si ha llegado un animal, cargamos sus datos en el layout
                binding.tvNombreDetalle.setText(animal.getNombre());
                binding.ivDetalle.setImageResource(animal.getImagen());
                binding.tvDescripcion.setText(animal.getDescripcion());
            } else {
                // En caso de error, podríamos volver atrás o mostrar un mensaje
                Toast.makeText(requireContext(), "No se pudo cargar el detalle del animal", Toast.LENGTH_SHORT).show();
                requireActivity().onBackPressed();
            }

        });

    }
}