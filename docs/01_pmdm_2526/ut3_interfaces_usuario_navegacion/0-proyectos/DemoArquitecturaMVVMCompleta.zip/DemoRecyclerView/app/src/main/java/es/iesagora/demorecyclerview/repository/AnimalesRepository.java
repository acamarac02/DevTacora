package es.iesagora.demorecyclerview.repository;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.demorecyclerview.R;
import es.iesagora.demorecyclerview.model.Animal;

public class AnimalesRepository {

    private List<Animal> listaAnimales;

    public AnimalesRepository() {
        listaAnimales = new ArrayList<>();
        listaAnimales.add(new Animal("Max", R.drawable.perro1, "Max es un labrador leal y juguetón."));
        listaAnimales.add(new Animal("Luna", R.drawable.gato1, "Luna es una gata curiosa y cazadora."));
        listaAnimales.add(new Animal("Paco", R.drawable.pajaro1, "Paco es un loro que habla mucho."));
        listaAnimales.add(new Animal("Spirit", R.drawable.caballo1, "Spirit es un caballo fuerte y veloz."));
        listaAnimales.add(new Animal("Rocky", R.drawable.perro2, "Rocky es un bulldog cariñoso y protector."));
        listaAnimales.add(new Animal("Simba", R.drawable.gato2, "Simba es un gato persa muy tranquilo."));
        listaAnimales.add(new Animal("Tweety", R.drawable.pajaro2, "Tweety es un canario de color amarillo."));
        listaAnimales.add(new Animal("Stella", R.drawable.caballo2, "Stella es una yegua amigable y rápida."));
        listaAnimales.add(new Animal("Bella", R.drawable.perro3, "Bella es una golden retriever amistosa."));
        listaAnimales.add(new Animal("Nala", R.drawable.gato3, "Nala es una gata independiente y elegante."));
    }

    public List<Animal> getAnimales() {
        return listaAnimales;
    }

    public Animal getAnimal(int position) {
        if (position >= 0 && position < listaAnimales.size()) {
            return listaAnimales.get(position);
        }
        return null; // Devuelve null si la posición no es válida
    }

    public void eliminarAnimal(Animal animal) {
        listaAnimales.remove(animal);
    }

    public void actualizarAnimal(Animal animal) {
        // Recuperamos la posición previa para volver a colocarlo en el mismo sitio
        int posicion = listaAnimales.indexOf(animal);
        // Colocamos el animal modificado en el mismo sitio
        listaAnimales.set(posicion, animal);
    }

    public List<Animal> getAnimalesPorNombre(String texto) {
        List<Animal> resultado = new ArrayList<>();
        for (Animal a : listaAnimales) {
            // Guardamos los animales cuyo nombre empieza por el texto indicando por el usuario
            if (a.getNombre().toLowerCase().startsWith(texto)) {
                resultado.add(a);
            }
        }
        return resultado;
    }
}
