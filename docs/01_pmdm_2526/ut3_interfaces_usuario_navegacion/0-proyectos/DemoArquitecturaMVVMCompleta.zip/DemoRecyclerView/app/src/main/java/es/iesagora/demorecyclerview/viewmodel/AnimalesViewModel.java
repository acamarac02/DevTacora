package es.iesagora.demorecyclerview.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import es.iesagora.demorecyclerview.model.Animal;
import es.iesagora.demorecyclerview.repository.AnimalesRepository;

public class AnimalesViewModel extends ViewModel {
    private AnimalesRepository repository;
    public MutableLiveData<List<Animal>> animales = new MutableLiveData<>();

    public MutableLiveData<Animal> animalSeleccionado = new MutableLiveData<>();

    public AnimalesViewModel() {
        repository = new AnimalesRepository();
    }

    public void obtenerAnimales() {
        animales.setValue(repository.getAnimales());
    }

    public void seleccionarAnimal(Animal animal) {
        animalSeleccionado.setValue(animal);
    }

    public void eliminarAnimal(int position) {
        // Obtenemos la lista actual del LiveData
        List<Animal> listaActual = animales.getValue();
        if (listaActual != null && position >= 0 && position < listaActual.size()) {
            Animal eliminado = listaActual.get(position);
            repository.eliminarAnimal(eliminado);
            animales.setValue(repository.getAnimales());
        }
    }

    public void actualizarAnimal(Animal animal) {
        repository.actualizarAnimal(animal);
    }

    public void buscarAnimalPorNombre(String texto) {
        animales.setValue(repository.getAnimalesPorNombre(texto));
    }
}
