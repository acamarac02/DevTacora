package es.iesagora.demorecyclerview.model;

import java.io.Serializable;
import java.util.Objects;

public class Animal implements Serializable {

    private String nombre;
    private int imagen; // ID del recurso drawable
    private String descripcion;
    private boolean favorito;

    public Animal(String nombre, int imagen, String descripcion) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.descripcion = descripcion;
        this.favorito = false;
    }

    public String getNombre() { return nombre; }
    public int getImagen() { return imagen; }

    public String getDescripcion() { return descripcion; }

    public boolean isFavorito() {
        return favorito;
    }

    public void setFavorito(boolean favorito) {
        this.favorito = favorito;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Animal)) return false;
        Animal animal = (Animal) o;
        return imagen == animal.imagen && Objects.equals(nombre, animal.nombre) && Objects.equals(descripcion, animal.descripcion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, imagen, descripcion);
    }
}
