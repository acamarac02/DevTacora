package es.iesagora.demorecyclerview.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.demorecyclerview.R;
import es.iesagora.demorecyclerview.databinding.ViewholderAnimalBinding;
import es.iesagora.demorecyclerview.model.Animal;
import es.iesagora.demorecyclerview.viewmodel.AnimalesViewModel;

public class AnimalesAdapter extends RecyclerView.Adapter<AnimalesAdapter.AnimalViewHolder> {

    private List<Animal> animales;            // Lista de animales a mostrar
    private final LayoutInflater inflater;    // Crea (infla) las vistas desde XML

    private AnimalesViewModel viewModel;

    // Constructor: recibe el contexto y la lista de animales
    public AnimalesAdapter(Context context, List<Animal> animales, AnimalesViewModel viewModel) {
        this.animales = animales;
        this.inflater = LayoutInflater.from(context);
        this.viewModel = viewModel;
    }

    // Crea un nuevo ViewHolder cuando el RecyclerView lo necesita
    @NonNull
    @Override
    public AnimalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Infla el layout del ViewHolder (viewholder_animal.xml)
        View view = inflater.inflate(R.layout.viewholder_animal, parent, false);
        return new AnimalViewHolder(view);
    }

    // Rellena los datos en el ViewHolder correspondiente a una posición concreta
    @Override
    public void onBindViewHolder(@NonNull AnimalViewHolder holder, int position) {
        Animal animal = animales.get(position);

        // Enlazamos los datos con los elementos del layout
        holder.binding.tvNombre.setText(animal.getNombre());
        holder.binding.ivAnimal.setImageResource(animal.getImagen());

        // Detectar el click sobre la tarjeta
        holder.itemView.setOnClickListener(v -> {
            // Guardamos el animal seleccionado en el ViewModel
            viewModel.seleccionarAnimal(animal);

            // Navegar al fragmento de detalle usando NavController
            NavController navController = Navigation.findNavController(v);
            navController.navigate(R.id.action_animalesFragment_to_detalleAnimalFragment);
        });

        // Cuando se cargue el RecyclerView, actualizamos el icono según el estado del animal
        establecerIconoFavorito(animal, holder);

        // Listener para el evento sobre el icono de favorito
        holder.binding.iconFavorite.setOnClickListener(v -> marcarFavorito(animal, holder));
    }

    // Método que se ejecuta en el evento de click sobre la estrella
    private void marcarFavorito(Animal animal, AnimalViewHolder holder) {
        // Cambiamos el estado del animal seleccionado
        if (animal.isFavorito()) animal.setFavorito(false);
        else animal.setFavorito(true);

        // Cambiamos el icono del animal seleccionado
        establecerIconoFavorito(animal, holder);

        // Actualizamos el estado del animal en base de datos (de momento el repository)
        // Recuerda que no podemos acceder al repository directamente, si no a través del ViewModel
        viewModel.actualizarAnimal(animal);
    }

    // Método que establece el icono según el estado del animal
    private void establecerIconoFavorito(Animal animal, AnimalViewHolder holder) {
        if (animal.isFavorito()) {
            holder.binding.iconFavorite.setImageResource(android.R.drawable.btn_star_big_on);
        } else {
            holder.binding.iconFavorite.setImageResource(android.R.drawable.btn_star_big_off);
        }
    }

    // Indica cuántos elementos hay en la lista
    @Override
    public int getItemCount() {
        return animales != null ? animales.size() : 0;
    }

    // Permite actualizar la lista completa desde fuera del adaptador
    public void establecerLista(List<Animal> animales) {
        this.animales = animales;
        notifyDataSetChanged(); // Notifica al RecyclerView que los datos han cambiado
    }

    // Clase interna ViewHolder que representa un solo elemento con ViewBinding
    public static class AnimalViewHolder extends RecyclerView.ViewHolder {

        // Objeto de enlace al layout viewholder_animal.xml
        ViewholderAnimalBinding binding;

        // El constructor recibe la vista del layout inflado
        public AnimalViewHolder(@NonNull View itemView) {
            super(itemView);
            // Asociamos el objeto binding con la vista
            binding = ViewholderAnimalBinding.bind(itemView);
        }
    }
}
