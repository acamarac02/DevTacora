// --- Configuración y Variables de Estado ---
const canvas = document.getElementById('drawing-canvas');
const ctx = canvas.getContext('2d');
const clearBtn = document.getElementById('clear-btn');
const uploadBtn = document.getElementById('upload-btn');
const imageInput = document.getElementById('image-input');
const predictBtn = document.getElementById('predict-btn');
const statusText = document.getElementById('status-text');

// Elementos de UI para cada modelo
const uiModels = {
    dense: {
        pred: document.getElementById('pred-dense'),
        conf: document.getElementById('conf-dense'),
        text: document.getElementById('text-dense')
    },
    cnnBasico: {
        pred: document.getElementById('pred-cnn-basico'),
        conf: document.getElementById('conf-cnn-basico'),
        text: document.getElementById('text-cnn-basico')
    },
    cnnProfundo: {
        pred: document.getElementById('pred-cnn-profundo'),
        conf: document.getElementById('conf-cnn-profundo'),
        text: document.getElementById('text-cnn-profundo')
    }
};

// Modelos
let models = {
    dense: null,
    cnnBasico: null,
    cnnProfundo: null
};

let isDrawing = false;

// Inicialización del canvas (Fondo blanco, pincel negro)
function initCanvas() {
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}
initCanvas();
ctx.lineWidth = 15;
ctx.lineCap = 'round';
ctx.strokeStyle = 'black';

// --- Lógica de Dibujo ---
function startDrawing(e) {
    isDrawing = true;
    draw(e);
}

function stopDrawing() {
    isDrawing = false;
    ctx.beginPath();
}

function draw(e) {
    if (!isDrawing) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);

    if (e.touches) e.preventDefault();
}

canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);
canvas.addEventListener('touchstart', startDrawing);
canvas.addEventListener('touchmove', draw);
canvas.addEventListener('touchend', stopDrawing);

// --- Carga de Modelos ---
async function loadModels() {
    try {
        statusText.innerText = "Cargando modelos...";

        // Cargar modelos en paralelo
        const [mDense, mCnnB, mCnnP] = await Promise.all([
            tf.loadLayersModel('modelo_mnist/model.json'),
            tf.loadLayersModel('modelo_cnn_basico/model.json'),
            tf.loadLayersModel('modelo_cnn_profundo/model.json')
        ]);

        models.dense = mDense;
        models.cnnBasico = mCnnB;
        models.cnnProfundo = mCnnP;

        statusText.innerText = "Modelos cargados correctamente.";
        console.log("All models loaded successfully");
    } catch (error) {
        statusText.innerText = "Error al cargar los modelos.";
        console.error("Error loading models:", error);
    }
}

// --- Procesamiento de Imagen y Predicción ---
async function predict() {
    if (!models.dense || !models.cnnBasico || !models.cnnProfundo) {
        alert("Los modelos no han terminado de cargar.");
        return;
    }

    statusText.innerText = "Procesando...";

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    // 1. Preprocesamiento (común para todos)
    const tensor = tf.tidy(() => {
        let img = tf.browser.fromPixels(imageData, 1);

        // Inteligencia de inversión
        const mean = img.mean().dataSync()[0];
        if (mean > 127) {
            img = tf.sub(255, img);
        }

        img = tf.image.resizeBilinear(img, [28, 28]);
        img = img.div(255.0);
        return img.expandDims(0);
    });

    // 2. Ejecutar cada modelo y actualizar su UI
    await runModelPrediction(models.dense, uiModels.dense, tensor);
    await runModelPrediction(models.cnnBasico, uiModels.cnnBasico, tensor);
    await runModelPrediction(models.cnnProfundo, uiModels.cnnProfundo, tensor);

    statusText.innerText = "Predicciones completadas.";
    tensor.dispose();
}

async function runModelPrediction(model, ui, tensor) {
    const prediction = model.predict(tensor);
    const results = await prediction.data();
    const predictedClass = prediction.argMax(1).dataSync()[0];
    const confidence = results[predictedClass];

    ui.pred.innerText = predictedClass;
    ui.conf.style.width = `${(confidence * 100).toFixed(1)}%`;
    ui.text.innerText = `${(confidence * 100).toFixed(1)}%`;

    prediction.dispose();
}

// --- Eventos de Botones ---
uploadBtn.addEventListener('click', () => imageInput.click());

imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            initCanvas();
            const scale = Math.min(canvas.width / img.width, canvas.height / img.height) * 0.7;
            const x = (canvas.width / 2) - (img.width / 2) * scale;
            const y = (canvas.height / 2) - (img.height / 2) * scale;
            ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
            statusText.innerText = "Imagen cargada. Haz clic en Predecir.";
        };
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
});

clearBtn.addEventListener('click', () => {
    initCanvas();
    Object.values(uiModels).forEach(ui => {
        ui.pred.innerText = '-';
        ui.conf.style.width = '0%';
        ui.text.innerText = '0%';
    });
    statusText.innerText = "Lienzo limpio.";
});

predictBtn.addEventListener('click', predict);

loadModels();
