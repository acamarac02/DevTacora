// --- Configuración y Variables de Estado ---
const canvas = document.getElementById('drawing-canvas');
const ctx = canvas.getContext('2d');
const clearBtn = document.getElementById('clear-btn');
const uploadBtn = document.getElementById('upload-btn');
const imageInput = document.getElementById('image-input');
const predictBtn = document.getElementById('predict-btn');
const predictionText = document.getElementById('prediction-text');
const confidenceFill = document.getElementById('confidence-fill');
const statusText = document.getElementById('status-text');

// Modelo
let model;
let isDrawing = false;

// Inicialización del canvas (Fondo blanco, pincel negro)
function initCanvas() {
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}
initCanvas();
ctx.lineWidth = 15;
ctx.lineCap = 'round';
ctx.strokeStyle = 'black';

// --- Lógica de Dibujo ---
function startDrawing(e) {
    isDrawing = true;
    draw(e);
}

function stopDrawing() {
    isDrawing = false;
    ctx.beginPath();
}

function draw(e) {
    if (!isDrawing) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);

    // Prevenir scroll en móviles
    if (e.touches) e.preventDefault();
}

canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);

// Soporte para touch
canvas.addEventListener('touchstart', startDrawing);
canvas.addEventListener('touchmove', draw);
canvas.addEventListener('touchend', stopDrawing);


// AQUÍ EMPIEZA EL CÓDIGO RELACIONADO CON NUESTRO MODELO DE IA

// --- Carga del Modelo ---
async function loadModel() {
    try {
        statusText.innerText = "Cargando modelo...";
        // Nota: Se asume que el modelo está en la subcarpeta modelo_mnist
        model = await tf.loadLayersModel('modelo_mnist/model.json');
        statusText.innerText = "Modelo cargado correctamente.";
        console.log("Model loaded successfully");
    } catch (error) {
        statusText.innerText = "Error al cargar el modelo.";
        console.error("Error loading model:", error);
    }
}

// --- Procesamiento de Imagen y Predicción ---
async function predict() {
    if (!model) {
        alert("El modelo no ha cargado todavía.");
        return;
    }

    statusText.innerText = "Procesando...";

    // 1. Obtener los datos del canvas
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    // 2. Convertir a Tensor y preprocesar
    const tensor = tf.tidy(() => {
        // Convierte el elemento visual (píxeles) en un Tensor numérico.
        // El '1' indica que lo queremos en escala de grises (un solo canal).
        let img = tf.browser.fromPixels(imageData, 1); // Escala de grises (1 canal)

        // Inteligencia de inversión:
        // MNIST espera fondo negro (0) y número blanco (255).
        // Si el promedio es alto (>127), el fondo es claro y hay que invertir.
        // Si el promedio es bajo, ya está en formato "tipo MNIST" y no invertimos.
        const mean = img.mean().dataSync()[0];
        if (mean > 127) {
            img = tf.sub(255, img);
        }

        img = tf.image.resizeBilinear(img, [28, 28]); // Redimensionar
        img = img.div(255.0); // Normalizar 0-1
        // 4 dimensiones: [Número de imágenes, Alto, Ancho, Color].
        // Añadimos una "dimensión de lote" (batch dimension) al inicio.
        // Aunque solo procesamos una imagen, la red espera un lote.
        img = img.expandDims(0); // Añadir dimensión de batch [1, 28, 28, 1]
        return img;
    });

    // 3. Predicción
    const prediction = model.predict(tensor);
    const results = await prediction.data(); // Predicciones para cada clase
    const predictedClass = prediction.argMax(1).dataSync()[0]; // Clase con mayor probabilidad
    const confidence = results[predictedClass]; // Probabilidad de la clase predicha

    // 4. Mostrar resultados
    predictionText.innerText = predictedClass;
    confidenceFill.style.width = `${(confidence * 100).toFixed(1)}%`;
    statusText.innerText = `Confianza: ${(confidence * 100).toFixed(1)}%`;

    // Liberar tensores
    tensor.dispose();
    prediction.dispose();
}

// --- Eventos de Botones ---
uploadBtn.addEventListener('click', () => imageInput.click());

imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            // Limpiar canvas primero
            initCanvas();

            // Calcular dimensiones para centrar y ajustar manteniendo proporción
            const scale = Math.min(canvas.width / img.width, canvas.height / img.height) * 0.7; // 70% del tamaño
            const x = (canvas.width / 2) - (img.width / 2) * scale;
            const y = (canvas.height / 2) - (img.height / 2) * scale;

            ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
            statusText.innerText = "Imagen cargada. Haz clic en Predecir.";
        };
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
});

clearBtn.addEventListener('click', () => {
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    predictionText.innerText = '-';
    confidenceFill.style.width = '0%';
    statusText.innerText = "Lienzo limpio.";
});

predictBtn.addEventListener('click', predict);

// Iniciar carga del modelo
loadModel();
